<?php



foreach($_POST['apen'] as $aap) {
    echo "<img src='../Plaatjes/Apen/".$aap.".jpg'>";
}