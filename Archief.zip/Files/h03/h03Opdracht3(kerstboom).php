<!DOCTYPE html>
<head>
    <title>h03 Opdracht 3</title>
    <style>
        body {
            text-align: center;
        }
    </style>
</head>
<body>


<?php
for ($i = 0; $i <=9; $i++) {
   for ($j = 0; $j<$i; $j++) {
       echo "*";
   }

    echo "*<br>";
}
?>
</body>
</html>

