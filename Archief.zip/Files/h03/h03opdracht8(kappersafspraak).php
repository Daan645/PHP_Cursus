<!DOCTYPE html>
<head>
    <title>h03 Opdracht 8: Kappers Afspraak</title>
</head>
<body>
<h2>foreach($kappersagenda as $afspraak => De volgende momenten zijn nog beschikbaar )</h2>

</body>
</html>


