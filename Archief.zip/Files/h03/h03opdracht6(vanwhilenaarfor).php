<!DOCTYPE html>
<head>
    <title>h03 Opdracht 6: van while naar for</title>
</head>
<body>


<?php
for ($x =35 ; $x >=0; $x--){
    echo "hoppelepee";
}
?>
</body>
</html>


