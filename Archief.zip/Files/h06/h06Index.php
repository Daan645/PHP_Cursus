<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="Opmaakindexh06.css">
    <meta charset="UTF-8">

    <title>Opdrachten Hoofdstuk: 6.</title>
</head>

<body>
<!--<img id="codefoto_links" src="Files/codefoto.jpg" alt="codefotolinks">-->
<!--<img id="codefoto_rechts" src="Files/codefoto.jpg" alt="codefotorechts">-->
<div class="wrapper">
    <header>
        <img id="php_logo" src="../Plaatjes/PHP-logo.svg" alt="php_logo">
        <h1>Opdrachten Hoofdstuk: 3 Daan Jacobs.</h1>
    </header>

    <nav>

        <h2>Links:</h2>
        <br>
        <a href="https://classroom.google.com/w/MzcyNzE3MTM5MjJa/t/all">PHP-Classroom</a>
        <a href="https://github.com/Daan645/PHPCursus">Github-Repository</a>
        <a href="phpcursusdaan.coolpage.biz">Website</a>

    </nav>
    <h2 id="kopje_hoofdstukken">Opdrachten:</h2>
    <ul>


        <li><a href="mysqlenphp.php"><button>Opdracht: 1</button></a></li>


    </ul>
</div>
</body>

</html>
